# TripMateFunctions/authentication.py

import uuid
import jwt

from django.conf import settings
from rest_framework import authentication, exceptions

from .models import AppUser


class SupabaseJWTAuthentication(authentication.BaseAuthentication):
    """
    Verify Supabase access tokens from the frontend.

    Header:
      Authorization: Bearer <supabase-access-token>
    """

    def authenticate(self, request):
        auth_header = authentication.get_authorization_header(request).decode("utf-8")

        if not auth_header:
            return None  # no header => anonymous

        parts = auth_header.split()
        if len(parts) != 2 or parts[0].lower() != "bearer":
            raise exceptions.AuthenticationFailed("Invalid Authorization header format")

        token = parts[1]

        secret = getattr(settings, "SUPABASE_JWT_SECRET", "")
        if not secret:
            raise exceptions.AuthenticationFailed("SUPABASE_JWT_SECRET not configured.")

        try:
            payload = jwt.decode(
                token,
                secret,
                algorithms=["HS256"],
                options={"verify_aud": False},
            )
        except jwt.ExpiredSignatureError:
            raise exceptions.AuthenticationFailed("Token expired")
        except jwt.InvalidTokenError:
            raise exceptions.AuthenticationFailed("Invalid token")

        supabase_user_id = payload.get("sub")  # Supabase user UUID string
        email = payload.get("email")

        if not supabase_user_id:
            raise exceptions.AuthenticationFailed("Token missing 'sub'")

        try:
            user_uuid = uuid.UUID(str(supabase_user_id))
        except Exception:
            raise exceptions.AuthenticationFailed("Token 'sub' is not a valid UUID")

        user, created = AppUser.objects.get_or_create(
            id=user_uuid,
            defaults={
                "email": email or f"{supabase_user_id}@no-email.local",
                "full_name": "",
                "status": AppUser.Status.VERIFIED,
                "role": AppUser.Role.NORMAL,
            },
        )

        if (not created) and email and user.email != email:
            user.email = email
            user.save(update_fields=["email", "updated_at"])

        # Optional: for debugging/use later in views
        request.supabase_claims = payload
        request.supabase_user_id = supabase_user_id

        # ✅ IMPORTANT: DO NOT set user.is_authenticated manually.
        return (user, token)
