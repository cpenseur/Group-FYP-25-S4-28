"""
Views package.

Intentionally kept minimal to reduce merge conflicts.
Import feature-specific views directly, e.g.:

from TripMateFunctions.views.f1_1_views import TripViewSet
"""
